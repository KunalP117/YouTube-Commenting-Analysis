load('category_switch_mod_1.mat');

% Aeq=zeros(24,4);
% beq=zeros(1,4);
% f=zeros(1,4);
% 
% for i=1:12
%     A(i,1)=ans(i,1); A(i,2)=-1;
%     A(i+12,3)=ans(i+12);A(i+12,4)=-1;
%     beq(i)=ans(i,2);
%     beq(i+12)=ans(i+12,2);
% end
% 
% lb=[0 -Inf 0 -Inf];
% ub=[Inf Inf Inf Inf];
% 
% [x,~,e]=linprog(f,[],[],Aeq,beq,lb,ub);

for count=1:153
    
    for i=1:12
        if joint_prob(count,i)== 0
           joint_prob(count,i) = 0.000001;
        end
        
        if joint_prob(count,i+12)== 0
           joint_prob(count,i+12) = 0.000001;
        end
            
    end
    
    joint_prob(count,1:12)=joint_prob(count,1:12)/(sum(joint_prob(count,1:12)));
    joint_prob(count,13:24)=joint_prob(count,13:24)/(sum(joint_prob(count,13:24)));
    
    
    for i=1:12
        if cond_prob(count,i)== 0
          cond_prob(count,i) = 0.000001;
        end
        
        if cond_prob(count,i+12)== 0
           cond_prob(count,i+12) = 0.000001;
        end
            
    end
    
    cond_prob(count,1:12)=cond_prob(count,1:12)/(sum(cond_prob(count,1:12)));
    cond_prob(count,13:24)=cond_prob(count,13:24)/(sum(cond_prob(count,13:24)));
    
    for i=1:6
        if prob_act(count,i)== 0
           prob_act(count,i) = 0.000001;
        end
        
        if prob_act(count,i+6)== 0
           prob_act(count,i+6) = 0.000001;
        end
            
    end
    
    prob_act(count,1:6)=prob_act(count,1:6)/(sum(prob_act(count,1:6)));
    prob_act(count,7:12)=prob_act(count,7:12)/(sum(prob_act(count,7:12)));
    
end